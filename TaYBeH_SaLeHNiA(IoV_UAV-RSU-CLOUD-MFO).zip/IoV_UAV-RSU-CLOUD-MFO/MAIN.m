clc;
clear all;
close all;

%===========================================
disp('====================================================================================');
disp('==================IoV+UAV+RSU+Cloud Simulation with MFO ============================');
disp('====================================================================================');
disp('Programmer : Taybeh Salehnia');
disp('Email      : salehnia.taybeh@gmail.com');
disp('=====================================================================================');

%% ================= Phase 1: System Definition =================
road_length = 3000;  % meters
road_width  = 500;   % meters

numVehicles = 120;
numUAVs     = 8;
numRSUs     = 4;
numCloud    = 1;

% Initialize all nodes in the system
[Vehicles, UAVs, RSUs, Cloud] = initializeSystem(numVehicles, numUAVs, numRSUs, road_length, road_width);

% Generate synthetic task dataset
taskSizes = [100 200 400 600 800 1000 2000 4000 6000 8000 10000]; 
Tasks = cell(length(taskSizes),1);
for i=1:length(taskSizes)
    Tasks{i} = generateTasks(taskSizes(i), Vehicles, UAVs, RSUs, Cloud);
end

%% ================= Phase 2: MFO Optimization =================
SearchAgents_no = 50;  % population size
Max_iteration  = 100;  % number of iterations
dim = length(Tasks{1}); % dimension = number of tasks

lb = 1; % node type index: 1=Vehicle, 2=UAV, 3=RSU, 4=Cloud
ub = 4;

% Define mobility-aware fitness function handle
fobj = @(X) fitnessMobilityAware(X, Tasks{1}, Vehicles, UAVs, RSUs, Cloud);

% Run MFO
[BestFitness, BestAllocation, Convergence_curve] = MFO_IoV(SearchAgents_no, Max_iteration, lb, ub, dim, fobj);

%% ================= Phase 3: Display Final Metrics =================
disp('------------------------- Final Results -------------------------');
disp(['Best Task Allocation and Scheduling Fitness: ', num2str(BestFitness)]);
disp('Best Task Allocation (1=Vehicle,2=UAV,3=RSU,4=Cloud):');
disp(BestAllocation);

% Compute final detailed metrics for display
[finalDelay, finalLoadBal, finalCost, finalTrust, finalEnergy] = computeMetricsMobility(BestAllocation, Tasks{1}, Vehicles, UAVs, RSUs, Cloud);

disp('--- Final Evaluation Metrics ---');
disp(['Total Delay: ', num2str(finalDelay), ' s']);
disp(['Load Balancing (Std of Node Loads): ', num2str(finalLoadBal)]);
disp(['Network Cost (Total Data Transmitted): ', num2str(finalCost), ' MB']);
disp(['Average Trust: ', num2str(finalTrust)]);
disp(['Remaining Energy in Nodes: ', num2str(finalEnergy)]);

% Plot convergence
figure;
plot(Convergence_curve,'LineWidth',2);
xlabel('Iteration'); ylabel('Fitness Value');
title('MFO Convergence Curve (Mobility-Aware)');
grid on;

