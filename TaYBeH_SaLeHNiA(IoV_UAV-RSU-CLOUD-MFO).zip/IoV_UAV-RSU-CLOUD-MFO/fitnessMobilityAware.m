%% --- Fitness Function ---
function fitness = fitnessMobilityAware(X, Tasks, Vehicles, UAVs, RSUs, Cloud)
    dt = 1; road_length=3000; road_width=500;
    for i=1:length(Vehicles)
        angle=rand*2*pi;
        Vehicles(i).x = mod(Vehicles(i).x + Vehicles(i).speed*dt*cos(angle), road_length);
        Vehicles(i).y = mod(Vehicles(i).y + Vehicles(i).speed*dt*sin(angle), road_width);
    end
    for i=1:length(UAVs)
        angle=rand*2*pi;
        UAVs(i).x = mod(UAVs(i).x + UAVs(i).speed*dt*cos(angle), road_length);
        UAVs(i).y = mod(UAVs(i).y + UAVs(i).speed*dt*sin(angle), road_width);
    end
    [totalDelay, loadBal, totalCost, avgTrust, remainingEnergy] = computeMetricsMobility(X, Tasks, Vehicles, UAVs, RSUs, Cloud);
    fitness = totalDelay + 0.1*totalCost + 0.5*loadBal - 0.2*avgTrust + 0.1*remainingEnergy;
end

