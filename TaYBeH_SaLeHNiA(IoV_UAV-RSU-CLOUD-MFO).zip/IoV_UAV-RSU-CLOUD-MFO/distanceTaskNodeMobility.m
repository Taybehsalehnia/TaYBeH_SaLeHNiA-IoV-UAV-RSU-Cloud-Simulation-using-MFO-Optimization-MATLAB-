%% --- Distance Function ---
function d = distanceTaskNodeMobility(task,Vehicles,UAVs,RSUs,Cloud,nodeType,nodeIdx)
    switch nodeType
        case 1, node=Vehicles(task.source);
        case 2, node=UAVs(nodeIdx - length(Vehicles));
        case 3, node=RSUs(nodeIdx - length(Vehicles) - length(UAVs));
        case 4, node=Cloud;
    end
    sourceNode=Vehicles(task.source);
    d = sqrt((sourceNode.x - node.x)^2 + (sourceNode.y - node.y)^2);
end
