%% --- System Initialization ---
function [Vehicles,UAVs,RSUs,Cloud] = initializeSystem(numVehicles,numUAVs,numRSUs,road_length,road_width)
    for i=1:numVehicles
        Vehicles(i).ID = i;
        Vehicles(i).x = rand*road_length;
        Vehicles(i).y = rand*road_width;
        Vehicles(i).speed = 20 + rand*10;
        Vehicles(i).resources.num = randi([1,7]);
        Vehicles(i).resources.capacity = rand(1,Vehicles(i).resources.num)*5 + 5;
        Vehicles(i).trust = 0.9 + rand*0.1;
    end
    for i=1:numUAVs
        UAVs(i).ID = i;
        UAVs(i).x = rand*road_length;
        UAVs(i).y = rand*road_width;
        UAVs(i).speed = 30 + rand*10;
        UAVs(i).resources.num = randi([1,3]);
        UAVs(i).resources.capacity = rand(1,UAVs(i).resources.num)*3 + 2;
        UAVs(i).connection_window = 5 + rand*5;
        UAVs(i).trust = 0.85 + rand*0.1;
    end
    for i=1:numRSUs
        RSUs(i).ID = i;
        RSUs(i).x = (i-1)*road_length/(numRSUs-1);
        RSUs(i).y = road_width/2;
        RSUs(i).resources.num = randi([5,10]);
        RSUs(i).resources.capacity = rand(1,RSUs(i).resources.num)*20 + 10;
        RSUs(i).trust = 0.95 + rand*0.05;
    end
    Cloud.ID = 1;
    Cloud.x = road_length/2;
    Cloud.y = road_width*2;
    Cloud.resources.num = 50;
    Cloud.resources.capacity = rand(1,Cloud.resources.num)*50 + 50;
    Cloud.trust = 1.0;
end

