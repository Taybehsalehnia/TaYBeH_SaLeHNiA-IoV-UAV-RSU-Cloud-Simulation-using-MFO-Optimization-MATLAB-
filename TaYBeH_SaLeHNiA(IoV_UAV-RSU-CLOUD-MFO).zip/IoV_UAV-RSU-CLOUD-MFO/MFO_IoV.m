%% ==================== Supporting Functions ====================

%% --- MFO Algorithm for IoV Task Allocation ---
function [Best_score, Best_pos, Convergence_curve] = MFO_IoV(N, Max_iter, lb, ub, dim, fobj)
    % Initialize moths
    Moth_pos = lb + rand(N,dim).*(ub-lb);
    Moth_fitness = inf(1,N);
    
    Convergence_curve = zeros(1, Max_iter);
    
    % Evaluate initial population
    for i=1:N
        Moth_fitness(i) = fobj(round(Moth_pos(i,:)));
    end
    
    % Initialize flames
    [sorted_fitness, I] = sort(Moth_fitness);
    sorted_population = Moth_pos(I,:);
    
    best_flames = sorted_population;
    best_flame_fitness = sorted_fitness;
    
    Best_score = sorted_fitness(1);
    Best_pos = sorted_population(1,:);
    
    Iteration = 1;
    
    while Iteration <= Max_iter
        Flame_no = round(N - Iteration*((N-1)/Max_iter));
        a = -1 + Iteration*((-1)/Max_iter); % linearly decreasing
        
        for i=1:N
            for j=1:dim
                if i <= Flame_no
                    distance = abs(best_flames(i,j) - Moth_pos(i,j));
                    b = 1;
                    t = (a-1)*rand + 1;
                    Moth_pos(i,j) = distance*exp(b*t)*cos(t*2*pi) + best_flames(i,j);
                else
                    distance = abs(best_flames(Flame_no,j) - Moth_pos(i,j));
                    b = 1;
                    t = (a-1)*rand +1;
                    Moth_pos(i,j) = distance*exp(b*t)*cos(t*2*pi) + best_flames(Flame_no,j);
                end
            end
            Moth_pos(i,:) = max(min(Moth_pos(i,:), ub), lb);
            Moth_fitness(i) = fobj(round(Moth_pos(i,:)));
        end
        
        % Combine and sort
        double_population = [best_flames; Moth_pos];
        double_fitness = [best_flame_fitness, Moth_fitness];
        [double_fitness_sorted, I2] = sort(double_fitness);
        double_sorted_population = double_population(I2,:);
        
        sorted_population = double_sorted_population(1:N,:);
        sorted_fitness = double_fitness_sorted(1:N);
        
        best_flames = sorted_population;
        best_flame_fitness = sorted_fitness;
        
        Best_score = sorted_fitness(1);
        Best_pos = sorted_population(1,:);
        Convergence_curve(Iteration) = Best_score;
        
        if mod(Iteration,10)==0
            disp(['Iteration ', num2str(Iteration), ' Best Fitness: ', num2str(Best_score)]);
        end
        Iteration = Iteration + 1;
    end
end

