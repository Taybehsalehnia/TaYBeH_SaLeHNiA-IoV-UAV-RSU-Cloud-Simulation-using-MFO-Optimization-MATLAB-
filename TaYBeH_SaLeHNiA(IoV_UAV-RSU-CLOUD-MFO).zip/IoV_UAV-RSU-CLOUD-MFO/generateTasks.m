%% --- Task Generation ---
function Tasks = generateTasks(numTasks,Vehicles,UAVs,RSUs,Cloud)
    for i=1:numTasks
        Tasks(i).ID = i;
        Tasks(i).source = randi(length(Vehicles));
        Tasks(i).size = rand*10 + 1;
        Tasks(i).data = rand*5 + 1;
        Tasks(i).deadline = 5 + rand*5;
        Tasks(i).priority = randi([1,3]);
    end
end

