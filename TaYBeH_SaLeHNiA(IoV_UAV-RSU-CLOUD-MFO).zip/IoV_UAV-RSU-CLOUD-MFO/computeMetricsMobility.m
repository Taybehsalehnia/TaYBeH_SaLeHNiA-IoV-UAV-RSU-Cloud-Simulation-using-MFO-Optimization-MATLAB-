%% --- Compute Metrics ---
function [totalDelay, loadBalancing, totalCost, avgTrust, remainingEnergy] = computeMetricsMobility(X, Tasks, Vehicles, UAVs, RSUs, Cloud)
    numTasks = length(Tasks);
    numNodes = length(Vehicles)+length(UAVs)+length(RSUs)+1;
    nodeLoad = zeros(numNodes,1); nodeTrust=zeros(numNodes,1); nodeEnergy=zeros(numNodes,1);
    for i=1:length(Vehicles); nodeTrust(i)=Vehicles(i).trust; nodeEnergy(i)=sum(Vehicles(i).resources.capacity); end
    for i=1:length(UAVs); nodeTrust(length(Vehicles)+i)=UAVs(i).trust; nodeEnergy(length(Vehicles)+i)=sum(UAVs(i).resources.capacity); end
    for i=1:length(RSUs); nodeTrust(length(Vehicles)+length(UAVs)+i)=RSUs(i).trust; nodeEnergy(length(Vehicles)+length(UAVs)+i)=sum(RSUs(i).resources.capacity); end
    nodeTrust(end)=Cloud.trust; nodeEnergy(end)=sum(Cloud.resources.capacity);
    
    totalDelay=0; totalCost=0; totalTrust=0;
    for t=1:numTasks
        task=Tasks(t);
        nodeType = round(X(t));
        switch nodeType
            case 1, nodeIdx=task.source;
            case 2, nodeIdx=length(Vehicles)+randi(length(UAVs));
            case 3, nodeIdx=length(Vehicles)+length(UAVs)+randi(length(RSUs));
            case 4, nodeIdx=numNodes;
        end
        nodeLoad(nodeIdx)=nodeLoad(nodeIdx)+task.size;
        dist=distanceTaskNodeMobility(task,Vehicles,UAVs,RSUs,Cloud,nodeType,nodeIdx);
        transmissionRate=10;
        transmissionDelay=task.data/transmissionRate + dist/100;
        processingCapacity=nodeEnergy(nodeIdx);
        processingDelay=task.size/processingCapacity;
        totalDelay=totalDelay + transmissionDelay + processingDelay;
        totalCost=totalCost + task.data;
        totalTrust=totalTrust + nodeTrust(nodeIdx);
        nodeEnergy(nodeIdx)=nodeEnergy(nodeIdx) - task.size*0.1;
    end
    loadBalancing=std(nodeLoad);
    avgTrust=totalTrust/numTasks;
    remainingEnergy=sum(nodeEnergy);
end

